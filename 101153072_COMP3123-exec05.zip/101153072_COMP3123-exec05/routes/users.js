const express = require('express');
const fs = require('fs');
const app = express();
const PORT = 3001;

const path = require('path');
const router = express.Router();

// ✅ GET /profile - return all details from user.json
router.get('/profile', (req, res) => {
    fs.readFile(path.join(__dirname, '../user.json'), 'utf8', (err, data) => {
        if (err) {
            return res.status(500).json({
                status: false,
                message: "Server Error"
            });
        }

        const user = JSON.parse(data);
        res.json(user);
    });
});

// ✅ POST /login - validate username/password from JSON body
router.post('/login', (req, res) => {
    const { username, password } = req.body;

    fs.readFile(path.join(__dirname, '../user.json'), 'utf8', (err, data) => {
        if (err) {
            return res.status(500).json({
                status: false,
                message: "Server Error"
            });
        }

        const user = JSON.parse(data);

        if (username !== user.username) {
            return res.json({
                status: false,
                message: "User Name is invalid"
            });
        }

        if (password !== user.password) {
            return res.json({
                status: false,
                message: "Password is invalid"
            });
        }

        return res.json({
            status: true,
            message: "User Is valid"
        });
    });
});

// ✅ GET /logout?username=xyz - return logout message in HTML
router.get('/logout', (req, res) => {
    const { username } = req.query;

    if (!username) {
        return res.status(400).send('<b>Username is required to logout.</b>');
    }

    res.send(`<b>${username} successfully logout.</b>`);
});

module.exports = router;

