const express = require('express');
const app = express();
const userRouter = require('./routes/users');
const path = require('path');
const router = express.Router();
const SERVER_PORT = process.env.PORT || 3001;

// Build in routes
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Application Level Middleware
app.use((req, res, next) => {
    console.log(`${req.method} ${req.url} - ${new Date().toISOString()}`);
    next();
});

app.use(express.static(path.join(__dirname, 'public')));
// Add User Router
app.use('/api/v1/users', userRouter);

app.get('/home', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'home.html'));
});


/*
- Create new html file name home.html 
- add <h1> tag with message "Welcome to ExpressJs Tutorial"
- Return home.html page to client
*/




/*
Add error handling middleware to handle below error
- Return 500 page with message "Server Error"
*/
app.get('/error-test', (req, res, next) => {
    const err = new Error('This is a simulated server error');
    next(err); // Pass the error to the error-handling middleware
});

app.use((err,req,res,next) => {
  console.log('Error Handling Middleware:', err.message);
  res.status(500).send('Server Error');
});

app.listen(process.env.port || 8083);

console.log('Web Server is listening at port '+ (process.env.port || 8083));